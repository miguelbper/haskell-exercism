module Meetup (Weekday(..), Schedule(..), meetupDay) where

import Data.Time.Calendar (Day(..), 
                           DayOfWeek(..),
                           fromGregorian, 
                           gregorianMonthLength, 
                           dayOfWeek, 
                           addDays,
                           firstDayOfWeekOnAfter                         
                           )

-- data Weekday = Monday
--              | Tuesday
--              | Wednesday
--              | Thursday
--              | Friday
--              | Saturday
--              | Sunday

type Weekday = DayOfWeek

data Schedule = First
              | Second
              | Third
              | Fourth
              | Last
              | Teenth

meetupDay :: Schedule -> DayOfWeek -> Integer -> Int -> Day
meetupDay schedule weekday year month = firstDayOfWeekOnAfter weekday day
    where
        day = case schedule of
            First  -> fromGregorian year month 1 
            Second -> fromGregorian year month 8  
            Third  -> fromGregorian year month 15 
            Fourth -> fromGregorian year month 21  
            Last   -> fromGregorian year month (gregorianMonthLength year month - 6)
            Teenth -> fromGregorian year month 13