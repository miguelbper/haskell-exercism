module Deque (Deque, mkDeque, pop, push, shift, unshift) where

import Control.Arrow ( (&&&))
import Control.Concurrent.MVar ( MVar, newMVar, newEmptyMVar, modifyMVar )
import Safe ( headMay )

type Deque a = MVar [a]

mkDeque :: IO (Deque a)
mkDeque = newMVar []

pop :: Deque a -> IO (Maybe a)
pop = flip modifyMVar $ return . (drop 1 &&& headMay)

push :: Deque a -> a -> IO ()
push deque x = error "You need to implement this function."

unshift :: Deque a -> a -> IO ()
unshift deque x = error "You need to implement this function."

shift :: Deque a -> IO (Maybe a)
shift deque = error "You need to implement this function."
