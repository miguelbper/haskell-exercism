module WordCount (wordCount) where

import Data.Text as T (words)
import Data.MultiSet as M (fromList, toOccurList)

wordCount :: Text -> [(Text, Int)]
wordCount = M.toOccurList . M.fromList . T.words
