module Atbash (decode, encode) where

import Data.Maybe ( fromMaybe )
import Data.List ( elemIndex ) 
import Data.Char ( toLower ) 
import Data.List.Split

alphabet    = ['a'..'z']
reversebet  = reverse alphabet
punctuation = [' ', '.', ',', '!']

atbash :: Char -> Char
atbash x
    | toLower x `elem` alphabet = reversebet !! fromMaybe 0 (elemIndex (toLower x) alphabet)
    | otherwise                 = x

decode :: String -> String
decode = map atbash . filter (not . (`elem` punctuation))

encode :: String -> String
encode = insert 5 ' ' . decode
    where
        insert :: Int -> a -> [a] -> [a]
        insert n y xs
            | n <= 0 || length xs <= n = xs
            | otherwise                = take n xs ++ [y] ++ insert n y (drop n xs)
