module Frequency (frequency) where

import Data.Map  (Map)
import Data.Text (Text)
import Control.Parallel.Strategies ( using, rdeepseq, parListChunk )

frequency :: Int -> [Text] -> Map Char Int
frequency nWorkers texts = error "You need to implement this function."


frequency' :: Text -> Map Char Int
frequency' tx = error "lmao"