module Matrix
    ( Matrix
    , cols
    , rows
    , flatten
    , shape
    , column
    , row
    , transpose
    , reshape
    , fromList
    , fromString
    ) where

import Data.Vector (Vector)
import qualified Data.Vector as V
import Control.Arrow ( Arrow((&&&)) )
import Data.List.Split (chunksOf)
import qualified Data.List as L
import Data.Maybe (listToMaybe)

data Matrix a = Matrix { cols    :: Int,
                         rows    :: Int,
                         flatten :: Vector a }

shape :: Matrix a -> (Int, Int)
shape = rows &&& cols

column :: Int -> Matrix a -> Vector a
column x = row x . transpose

row :: Int -> Matrix a -> Vector a
row x matrix = V.fromList (toList matrix !! x)

transpose :: Matrix a -> Matrix a
transpose = fromList . L.transpose . toList 

reshape :: (Int, Int) -> Matrix a -> Matrix a
reshape (r, c) (Matrix _ _ v) = Matrix r c v

toList :: Matrix a -> [[a]]
toList (Matrix r c v) = chunksOf c . V.toList $ v

fromList :: [[a]] -> Matrix a
fromList xss = Matrix r c v
    where
        r = length xss
        c = length . head $ xss
        v = V.fromList . concat $ xss

fromString :: Read a => String -> Matrix a
fromString = fromList . map (L.unfoldr (listToMaybe . reads)) . lines




