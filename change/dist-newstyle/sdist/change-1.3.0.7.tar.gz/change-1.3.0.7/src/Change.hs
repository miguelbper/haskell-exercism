module Change (findFewestCoins) where

import Data.Safe ( headMay )
import Control.Monad ( liftM2 )

findFewestCoins :: Integer -> [Integer] -> Maybe [Integer]
findFewestCoins = headMay . candidates

candidates :: Integer -> [Integer] -> [[Integer]]
candidates = error "lol"
